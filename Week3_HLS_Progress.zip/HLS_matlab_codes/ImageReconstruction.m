clear; clf;
rng('shuffle');
% --- Image and Sparsity Parameters ---
image_size = 128;
N = image_size * image_size; % Total signal length (65536)
K = round(0.125 * N); % Adjust K proportionally (e.g., 12.5% of N, now ~2048)

tolerance = 1e-6; 
num_trials = 1; % Single trial for deterministic image recovery
% Sample rates (M/N) to sweep
sample_rates = [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9];
%sample_rates = [0.9];
num_rates = length(sample_rates);
% --- Load and Sparsify Image (Requires Image Processing Toolbox) ---
% NOTE: Ensure 'lena.png' or a similar 256x256 image is available.

    img = imread('Lena.jpg'); 
    if size(img, 3) == 3
        img = rgb2gray(img);
    end
    x_true_img_full = double(imresize(img, [image_size, image_size])) / 255;

% Get sparse coefficients (alpha) using 2D-DCT
alpha_true_2d = dct2(x_true_img_full);
alpha_true = alpha_true_2d(:);
% Sparsify the signal: Keep the top K coefficients
[~, idx_sorted] = sort(abs(alpha_true), 'descend');
alpha_true_sparse = zeros(N, 1);
alpha_true_sparse(idx_sorted(1:K)) = alpha_true(idx_sorted(1:K));
x_true_img = idct2(reshape(alpha_true_sparse, image_size, image_size));
x_true = x_true_img(:); % Ground truth signal
% --- Store results ---
psnr_values = zeros(1, num_rates);
% --- Main Simulation Loop (Sweeping Sample Rates M/N) ---
for i = 1:num_rates
    fprintf("Rate : %d\n",i);
    rate = sample_rates(i);
    M = round(rate * N); % Current number of measurements M
    
    if M < K
        psnr_values(i) = -30; % Assign low PSNR if M < K
        continue; 
    end
    % 1. Define the Measurement Matrix A (M x N)
    A = randn(M, N) / sqrt(M); % Normalized Gaussian matrix
    
    current_psnr_sum = 0; 
    
    for trial = 1:num_trials 
        
        % 2. Generate measurements: y = A * x_true
        y_vec = A * x_true; 
        % --- Algorithm 3 OMP Implementation ---
        
        % Line 1: Initialization
        r = y_vec; % Current residual
        Lambda = []; % Indices of selected DCT atoms
        Q = []; % Orthonormal basis Q for the selected columns (M x t)
        A_Lambda = []; % Selected columns of A*Psi (M x t), for Least Squares at the end
        % Line 2: for t < K do
        for t = 1:K 
            fprintf("Current iter = %d\n",t);
            % --- Line 3: Atom Selection: max |Phi' * r| ---
            % Phi' * r = Psi' * (A' * r)
            A_transpose_r_vec = A' * r; 
            Phi_transpose_r_2d = dct2(reshape(A_transpose_r_vec, image_size, image_size));
            correlation_vector = Phi_transpose_r_2d(:);
            
            [~, lambda_t] = max(abs(correlation_vector));
            
            % Check if atom is already selected
            if ismember(lambda_t, Lambda)
                break; 
            end
            
            % Line 4: Atom Update (Lambda)
            Lambda(end+1) = lambda_t;    %#ok<SAGROW>
            
            % Get the selected atom (column) a_t = Phi(:, lambda_t)
            % Phi(:, lambda_t) = A * Psi(:, lambda_t)
            psi_t_vec = zeros(N, 1);
            psi_t_vec(lambda_t) = 1;
            psi_t_img = idct2(reshape(psi_t_vec, image_size, image_size));
            a_t = A * psi_t_img(:); % a_t is M x 1 (This is the atom A_tj in the algorithm)
            
            % Store atom for final Least Squares
            A_Lambda = [A_Lambda, a_t]; %#ok<AGROW>
            % --- Lines 5-11: Gram-Schmidt Orthogonalization ---
            
            % Line 5 is implicitly handled on the first iteration by Line 11/12
            % Line 6: j = t (using t for the index of the new orthonormal vector)
            q_t = a_t; % Initialize Q_j (the orthogonal vector)
            
            % Line 7: for 0 <= j < i do (orthogonalize against existing Q's)
            for j = 1:size(Q, 2)
                % Line 8: h = sum (A_tj^T Q_i) Q_i
                h = Q(:,j)' * a_t; % Inner product (A_tj^T Q_i)
                q_t = q_t - h * Q(:,j); % Q_j_hat = A_tj - h (Line 10 implicitly)
            end
            
            % Line 11: Normalization
            norm_q_t = norm(q_t);
            if norm_q_t < 1e-9 % Avoid division by zero
               break; 
            end
            q_t = q_t / norm_q_t;
            Q = [Q, q_t]; %#ok<AGROW> % Update the orthonormal basis
            % Line 12: Residual Update
            % r_t = r_t-1 - Q_t Q_t^T r_t-1
            r = r - (q_t' * r) * q_t; 
            
            % Line 13: t=t+1 (handled by loop)
        end
        % Line 14: End for
        % --- Lines 15-16: Least Squares and Final Reconstruction ---
        
        alpha_hat = zeros(N, 1);
        if ~isempty(Lambda) && (size(A_Lambda, 2) == K) 
            % Line 15: Least Squares
            % Use the selected atoms A_Lambda (which is A_hat in the algo)
            theta_hat = A_Lambda \ y_vec; 
            
            % Map coefficients to the full alpha_hat vector
            alpha_hat(Lambda) = theta_hat;
            % Line 16: x_hat = Psi * theta (reconstruct x from alpha_hat)
            x_hat_img = idct2(reshape(alpha_hat, image_size, image_size));
            x_hat = x_hat_img(:);
        else
            x_hat = zeros(N, 1); % Reconstruction failed/empty
        end
        
        % --- Calculate PSNR ---
        MSE = norm(x_hat - x_true)^2 / N; 
        PSNR = 10 * log10(1^2 / MSE); 
        current_psnr_sum = current_psnr_sum + PSNR;
    end
    
    psnr_values(i) = current_psnr_sum / num_trials;
    fprintf('Rate = %.1f, M = %d, PSNR = %.2f dB\n', rate, M, psnr_values(i));

    % --- NEW CODE: Display and Save Reconstructed Image at rate = 0.5 ---
    if rate == 0.5
        % Display original and reconstructed image in a new figure
        figure(2); clf;
        subplot(1, 2, 1); 
        imshow(x_true_img); 
        title('(a) Original Image (Sparse Approx.)');
        
        subplot(1, 2, 2); 
        imshow(x_hat_img); 
        title(['(b) Reconstructed Image (M/N=0.5, PSNR=', num2str(PSNR, '%.2f'), ')']);
        
        % Save the reconstructed image file
        filename = ['reconstructed_lena_rate_', num2str(rate, '%.1f'), '.png'];
        imwrite(x_hat_img, filename);
        fprintf('Saved reconstructed image to %s\n', filename);
    end
    % ---------------------------------------------------------------------

end
% --- Plotting Section (Fig. 6(c) format) ---
figure('Color','w');
plot(sample_rates, psnr_values, 'o-', 'LineWidth', 2, 'MarkerSize', 6, 'Color', 'b');
h_plot_axes = gca; % Get handle to current axes

hold on;
% Find the point closest to M/N = 0.2 
[~, idx_25] = min(abs(sample_rates - 0.2)); 
% Plot the specific marker for M/N = 0.2
plot(sample_rates(idx_25), psnr_values(idx_25), 'k<', 'MarkerSize', 10, 'MarkerFaceColor', 'b');
% Add the text 
text_x = sample_rates(idx_25) + 0.02;
text_y = psnr_values(idx_25) - 5;
text(text_x, text_y, ['(PSNR=', num2str(psnr_values(idx_25), '%.2f'), ')'], 'HorizontalAlignment', 'left');

% --- MODIFIED: Robust Annotation Arrow Positioning ---
% Get current plot limits
x_limits = get(h_plot_axes, 'XLim');
y_limits = get(h_plot_axes, 'YLim');

% Get the position of the axes within the figure (normalized [0,1])
axes_pos = get(h_plot_axes, 'Position');

% Convert data coordinates (sample_rates(idx_25), psnr_values(idx_25))
% to normalized figure coordinates [0,1] for the annotation.
% This is more robust as it uses the *actual* plot limits.
x_data = sample_rates(idx_25);
y_data = psnr_values(idx_25);

% Calculate normalized coordinates relative to the axes
x_norm_in_axes = (x_data - x_limits(1)) / (x_limits(2) - x_limits(1));
y_norm_in_axes = (y_data - y_limits(1)) / (y_limits(2) - y_limits(1));

% Convert normalized axes coordinates to normalized figure coordinates
x_fig = axes_pos(1) + x_norm_in_axes * axes_pos(3);
y_fig = axes_pos(2) + y_norm_in_axes * axes_pos(4);

% Define start and end points of the arrow in normalized figure coordinates
% Adjust these values to position the arrow correctly relative to the text and marker
arrow_start_x = x_fig + 0.05; % Start slightly right of the marker
arrow_start_y = y_fig - 0.1;  % Start slightly below the marker

arrow_end_x = x_fig + 0.01;   % End closer to the marker
arrow_end_y = y_fig - 0.01;   % End closer to the marker

% Ensure coordinates are within [0,1] range (clamping if necessary, though good calculation prevents it)
arrow_start_x = max(0, min(1, arrow_start_x));
arrow_start_y = max(0, min(1, arrow_start_y));
arrow_end_x = max(0, min(1, arrow_end_x));
arrow_end_y = max(0, min(1, arrow_end_y));

annotation('textarrow', ...
    [arrow_start_x, arrow_end_x], ...
    [arrow_start_y, arrow_end_y], ...
    'String', '', 'HeadStyle', 'vback2', 'LineWidth', 1);

title('Image reconstruction results and PSNR using Algorithm 3 OMP (128x128)');
xlabel('Sample rate (M/N)');
ylabel('PSNR (dB)');
grid on;
xlim([0.1 0.95]);
ylim([-30 40]);