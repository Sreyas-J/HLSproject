S = load('PSNR.mat');
idx = [0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9];
figure('Color','w');
plot(idx,S.psnr_values,'o-', 'LineWidth', 1, 'MarkerSize', 4, 'Color', 'b');
title('Image reconstruction results and PSNR using Algorithm 3 OMP (128x128)');
xlabel('Sample rate (M/N)');
ylabel('PSNR (dB)');
xlim([0.1 0.7]);
grid on;