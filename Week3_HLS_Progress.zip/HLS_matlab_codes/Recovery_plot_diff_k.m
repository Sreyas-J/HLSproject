clear; clf;
rng('shuffle');  % Change seed each run; use rng(0) for reproducibility

% --- Experiment Parameters ---
% Sparsity levels (K) to test (these will define the legend)
K_values = [12, 18, 24, 30, 36]; 
N = 256; % Fixed signal dimension
tolerance = 1e-6;   % Euclidean error threshold for a successful recovery
num_trials = 500;   % Number of trials per (K, M) pair

% Range of measurement values (M) to sweep (these will be the x-axis)
M_values = 5:250;
num_M = length(M_values);

% Initialize plotting
figure('Color','w');
hold on; % Keep multiple plots on the same figure

% --- Outer Loop for different K values (The legend) ---
for k_idx = 1:length(K_values)
    K = K_values(k_idx); % Current sparsity level
    
    % Store success rates for the current K
    success_rates = zeros(1, num_M);
    
    % --- Main Simulation Loop (Inner) ---
    for i = 1:num_M
        M = M_values(i); % Current number of measurements
        
        % Fix measurement matrix A for the current M
        A = randn(M, N);
        
        successes = 0;
        
        for trial = 1:num_trials
            % Generate a K-sparse signal x_true
            x_true = zeros(N,1);
            idx = randperm(N, K);
            x_true(idx) = randn(K,1);
            
            % Generate measurements
            y = A * x_true;
            
            % --- OMP with Gram-Schmidt ---
            r = y;
            Lambda = [];
            Q = [];
            
            % OMP loop runs up to K iterations, constrained by M
            % The algorithm cannot run longer than M iterations (must have M >= K)
            max_iter = min(K, M); 
            
            for t = 1:max_iter
                % Find best atom
                [~, lambda_t] = max(abs(A' * r));
                
                % Check if atom is already selected
                if ismember(lambda_t, Lambda)
                    break; 
                end
                
                Lambda(end+1) = lambda_t;    %#ok<SAGROW>
                a_t = A(:, lambda_t);
                
                % Orthogonalize atom (Gram-Schmidt)
                q_t = a_t;
                for j = 1:size(Q,2)
                    h = Q(:,j)' * a_t;
                    q_t = q_t - h * Q(:,j);
                end
                
                % Normalization
                norm_q_t = norm(q_t);
                if norm_q_t < 1e-9 
                   break; % Stop if vectors become linearly dependent
                end
                q_t = q_t / norm_q_t;
                Q = [Q, q_t]; %#ok<AGROW>
                
                % Update residual
                r = r - (q_t' * r) * q_t;
            end
            
            % Reconstruct x_hat
            x_hat = zeros(N,1);
            % Only attempt reconstruction if the algorithm ran for K iterations
            if ~isempty(Lambda) && (size(Lambda, 2) == K) 
                A_hat = A(:, Lambda);
                theta = A_hat \ y; 
                x_hat(Lambda) = theta;
            end
            
            % Check success
            err = norm(x_hat - x_true);
            if err < tolerance
                successes = successes + 1;
            end
        end
        
        % Store success rate (%)
        success_rates(i) = (successes / num_trials) * 100;
        % fprintf('K = %d, M = %d, Success Rate = %.2f%%\n', K, M, success_rates(i));
    end
    
    % --- Plotting Section ---
    % Use K value as the DisplayName for the legend
    % NOTE: For the plot to exactly match the colors/markers, you would need
    % to specify them explicitly (e.g., 'k-s' for black square, 'y-o' for yellow circle, etc.)
    plot(M_values, success_rates,'o-', 'LineWidth', 1, 'MarkerSize', 3, ...
         'DisplayName', ['K = ', num2str(K)]);
end

% --- Final Plot Formatting ---
hold off; % Release the figure
title('Success Rate as a Function of Number of Measurements (M)');
xlabel('Number of measurements (M)');
ylabel('Success rate (%)');
legend('Location','southeast');
grid on;
% Axis formatting (matches the reference image)
xlim([0 250]);
ylim([0 100]);