clear; clf;
rng('shuffle');  % Change seed each run; use rng(0) for reproducibility

% Problem parameters
M_values = [50, 100, 150, 200, 250]; % Different M values to test
N = 256; % Fixed signal dimension
tolerance = 1e-6;   % Euclidean error threshold for a successful recovery
num_trials = 500;   % Number of trials per sparsity level

% Range of sparsity levels
K_values = 5:120;
num_K = length(K_values);

% Initialize plotting
figure('Color','w');
hold on; % Keep multiple plots on the same figure

% Store all success rates for later reference (optional)
all_success_rates = zeros(length(M_values), num_K);

% --- Outer Loop for different M values ---
for m_idx = 1:length(M_values)
    M = M_values(m_idx); % Current number of measurements
    
    % Fix measurement matrix A for the current M
    A = randn(M, N);
    
    % Store success rates for the current M
    success_rates = zeros(1, num_K);
    
    % --- Main Simulation Loop (Inner) ---
    for i = 1:num_K
        K = K_values(i); % Current sparsity level
        successes = 0;
        
        for trial = 1:num_trials
            % Generate a K-sparse signal x_true
            x_true = zeros(N,1);
            idx = randperm(N, K);
            x_true(idx) = randn(K,1);
            
            % Generate measurements
            y = A * x_true;
            
            % --- OMP with Gram-Schmidt ---
            r = y;
            Lambda = [];
            Q = [];
            
            % OMP loop runs up to K iterations
            for t = 1:K
                % Find best atom
                [~, lambda_t] = max(abs(A' * r));
                
                % Check if atom is already selected (basic check, can be improved)
                if ismember(lambda_t, Lambda)
                    break; % Exit OMP if the same atom is selected again
                end
                
                Lambda(end+1) = lambda_t;    %#ok<SAGROW>
                a_t = A(:, lambda_t);
                
                % Orthogonalize atom (Gram-Schmidt)
                q_t = a_t;
                for j = 1:size(Q,2)
                    h = Q(:,j)' * a_t;
                    q_t = q_t - h * Q(:,j);
                end
                
                % Normalization
                norm_q_t = norm(q_t);
                if norm_q_t < 1e-9 % Prevent division by zero/near-zero (e.g., if A columns are linearly dependent)
                   break; 
                end
                q_t = q_t / norm_q_t;
                Q = [Q, q_t]; %#ok<AGROW>
                
                % Update residual
                r = r - (q_t' * r) * q_t;
            end
            
            % Reconstruct x_hat
            x_hat = zeros(N,1);
            if ~isempty(Lambda) && (size(Lambda, 2) == size(Q, 2)) % Ensure OMP completed successfully
                % Solve the least squares problem using the selected columns
                A_hat = A(:, Lambda);
                % The backslash operator (\) solves the least squares problem A_hat * theta = y
                theta = A_hat \ y; 
                x_hat(Lambda) = theta;
            end
            
            % Check success
            err = norm(x_hat - x_true);
            if err < tolerance
                successes = successes + 1;
            end
        end
        
        % Store success rate (%)
        success_rates(i) = (successes / num_trials) * 100;
        %fprintf('M = %d, K = %d, Success Rate = %.2f%%\n', M, K, success_rates(i));
    end
    
    % Store the results (optional)
    all_success_rates(m_idx, :) = success_rates;
    
    % --- Plotting Section ---
    % Use M value as the DisplayName for the legend
    plot(K_values, success_rates,'o-', 'LineWidth', 1, 'MarkerSize', 3, ...
         'DisplayName', ['M = ', num2str(M)]);
end

% --- Final Plot Formatting ---
hold off; % Release the figure
title('Success Rate as a Function of Sparsity Level (K) for various M');
xlabel('Sparsity level (K)');
ylabel('Success rate (%)');
legend('Location','SouthWest');
grid on;
% Axis formatting
xlim([min(K_values)-5 max(K_values)+5]);
ylim([0 100]);